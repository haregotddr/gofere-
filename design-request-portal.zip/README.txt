GOFERE Design Request Portal
============================

Open index.html in a modern browser.

Included:
- Responsive multi-step form (About You, Design Specifications, Design Brief, Before You Send, Thank You)
- Garment and collar reference images extracted from the supplied PDF
- Conditional sections for item type, inspiration, logos, sponsors, and names/numbers
- Local file upload controls and form validation

Important:
This is a front-end recreation. Submissions currently show a local confirmation page and are not sent to a server or email. To receive real orders, connect the form to a backend/form service and configure secure file storage.
